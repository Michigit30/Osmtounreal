bl_info = {
    "name": "OSM Builder Pro",
    "author": "Custom",
    "version": (2, 0, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > OSM Builder",
    "description": "Generiert komplette Städte aus OSM-Daten mit minimalen Assets",
    "category": "Import-Export",
}

import bpy
from .operators.fetch_osm       import OSM_OT_FetchData
from .operators.build_buildings import OSM_OT_BuildBuildings
from .operators.build_roads     import OSM_OT_BuildRoads
from .operators.build_vegetation import OSM_OT_BuildVegetation
from .operators.export_fbx      import OSM_OT_ExportFBX
from .operators.export_json     import OSM_OT_ExportJSON
from .operators.clear_scene     import OSM_OT_ClearScene
from .ui.panel                  import (
    OSM_PT_MainPanel, OSM_PT_AssetsPanel,
    OSM_PT_StylePanel, OSM_PT_ExportPanel
)

classes = [
    OSM_OT_FetchData,
    OSM_OT_BuildBuildings,
    OSM_OT_BuildRoads,
    OSM_OT_BuildVegetation,
    OSM_OT_ExportFBX,
    OSM_OT_ExportJSON,
    OSM_OT_ClearScene,
    OSM_PT_MainPanel,
    OSM_PT_AssetsPanel,
    OSM_PT_StylePanel,
    OSM_PT_ExportPanel,
]

def register_properties():
    S = bpy.types.Scene

    # Standort
    S.osm_lat    = bpy.props.FloatProperty(name="Breitengrad",  default=52.5200, precision=6)
    S.osm_lon    = bpy.props.FloatProperty(name="Längengrad",   default=13.4050, precision=6)
    S.osm_radius = bpy.props.FloatProperty(name="Radius (m)",   default=300.0, min=50, max=2000)

    # Gebäude-Asset-Slots (alle optional)
    S.osm_wall_mesh     = bpy.props.StringProperty(name="Wand-Mesh (optional)")
    S.osm_roof_flat     = bpy.props.StringProperty(name="Flachdach (optional)")
    S.osm_roof_gabled   = bpy.props.StringProperty(name="Giebeldach (optional)")
    S.osm_tree_mesh     = bpy.props.StringProperty(name="Baum-Mesh (optional)")

    # Straßen-Asset-Slots (optional)
    S.osm_road_mesh     = bpy.props.StringProperty(name="Straßen-Mesh (optional)")

    # Stil-Einstellungen
    S.osm_wall_color        = bpy.props.FloatVectorProperty(name="Wand-Farbe",    subtype="COLOR", default=(0.8, 0.75, 0.65), min=0, max=1)
    S.osm_roof_color        = bpy.props.FloatVectorProperty(name="Dach-Farbe",    subtype="COLOR", default=(0.55, 0.25, 0.15), min=0, max=1)
    S.osm_road_color        = bpy.props.FloatVectorProperty(name="Straßen-Farbe", subtype="COLOR", default=(0.2, 0.2, 0.2),   min=0, max=1)
    S.osm_vegetation_color  = bpy.props.FloatVectorProperty(name="Baum-Farbe",    subtype="COLOR", default=(0.15, 0.5, 0.1),  min=0, max=1)
    S.osm_floor_height      = bpy.props.FloatProperty(name="Stockwerk-Höhe (m)",  default=3.0, min=1.0, max=6.0)
    S.osm_default_floors    = bpy.props.IntProperty  (name="Standard-Stockwerke", default=3,   min=1,   max=50)
    S.osm_random_seed       = bpy.props.IntProperty  (name="Zufalls-Seed",        default=42)
    S.osm_variation         = bpy.props.FloatProperty(name="Variation (%)",       default=10.0, min=0, max=30)

    # Export
    S.osm_export_path = bpy.props.StringProperty(name="Export Pfad", subtype="DIR_PATH", default="//")

def unregister_properties():
    props = [
        "osm_lat","osm_lon","osm_radius",
        "osm_wall_mesh","osm_roof_flat","osm_roof_gabled","osm_tree_mesh","osm_road_mesh",
        "osm_wall_color","osm_roof_color","osm_road_color","osm_vegetation_color",
        "osm_floor_height","osm_default_floors","osm_random_seed","osm_variation",
        "osm_export_path",
    ]
    for p in props:
        if hasattr(bpy.types.Scene, p):
            delattr(bpy.types.Scene, p)

def register():
    register_properties()
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    unregister_properties()
