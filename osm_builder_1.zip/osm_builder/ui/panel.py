import bpy
import json
from bpy.types import Panel


def json_count(raw):
    try:
        return len(json.loads(raw))
    except:
        return 0


class OSM_PT_MainPanel(Panel):
    bl_label      = "OSM Builder Pro"
    bl_idname     = "OSM_PT_MainPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type= "UI"
    bl_category   = "OSM Builder"

    def draw(self, context):
        layout = self.layout
        sc     = context.scene

        has_data = bool(sc.get("_osm_buildings"))
        if has_data:
            b = json_count(sc.get("_osm_buildings","[]"))
            r = json_count(sc.get("_osm_roads","[]"))
            t = json_count(sc.get("_osm_trees","[]"))
            box = layout.box()
            box.label(text=f"✓ Daten: {b} Geb. · {r} Str. · {t} Bäume", icon="CHECKMARK")

        box = layout.box()
        box.label(text="Standort", icon="WORLD")
        box.prop(sc, "osm_lat")
        box.prop(sc, "osm_lon")
        box.prop(sc, "osm_radius")
        box.operator("osm.fetch_data", icon="IMPORT", text="OSM Daten laden")

        layout.separator()

        box = layout.box()
        box.label(text="Generieren", icon="MESH_DATA")
        col = box.column(align=True)
        col.operator("osm.build_buildings",  icon="HOME",            text="Gebäude")
        col.operator("osm.build_roads",      icon="DRIVER_DISTANCE", text="Straßen")
        col.operator("osm.build_vegetation", icon="OUTLINER_OB_FORCE_FIELD", text="Vegetation & Bäume")

        layout.separator()
        layout.operator("osm.clear_scene", icon="TRASH")


class OSM_PT_StylePanel(Panel):
    bl_label      = "Stil & Einstellungen"
    bl_idname     = "OSM_PT_StylePanel"
    bl_space_type = "VIEW_3D"
    bl_region_type= "UI"
    bl_category   = "OSM Builder"
    bl_options    = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        sc     = context.scene

        box = layout.box()
        box.label(text="Gebäude", icon="HOME")
        box.prop(sc, "osm_floor_height")
        box.prop(sc, "osm_default_floors")
        box.prop(sc, "osm_variation")
        box.prop(sc, "osm_random_seed")

        box = layout.box()
        box.label(text="Farben (ohne eigene Meshes)", icon="MATERIAL")
        box.prop(sc, "osm_wall_color")
        box.prop(sc, "osm_roof_color")
        box.prop(sc, "osm_road_color")
        box.prop(sc, "osm_vegetation_color")


class OSM_PT_AssetsPanel(Panel):
    bl_label      = "Eigene Assets (optional)"
    bl_idname     = "OSM_PT_AssetsPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type= "UI"
    bl_category   = "OSM Builder"
    bl_options    = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        sc     = context.scene

        layout.label(text="Alle Felder optional – ohne Mesh = prozedural", icon="INFO")

        box = layout.box()
        box.label(text="Gebäude", icon="HOME")
        box.prop_search(sc, "osm_wall_mesh",   bpy.data, "objects", text="Wand-Mesh")
        box.prop_search(sc, "osm_roof_flat",   bpy.data, "objects", text="Flachdach")
        box.prop_search(sc, "osm_roof_gabled", bpy.data, "objects", text="Giebeldach")

        box = layout.box()
        box.label(text="Straße & Natur", icon="DRIVER_DISTANCE")
        box.prop_search(sc, "osm_road_mesh",   bpy.data, "objects", text="Straßen-Mesh")
        box.prop_search(sc, "osm_tree_mesh",   bpy.data, "objects", text="Baum-Mesh")


class OSM_PT_ExportPanel(Panel):
    bl_label      = "Export"
    bl_idname     = "OSM_PT_ExportPanel"
    bl_space_type = "VIEW_3D"
    bl_region_type= "UI"
    bl_category   = "OSM Builder"
    bl_options    = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        sc     = context.scene

        has_data = bool(sc.get("_osm_roads") or sc.get("_osm_buildings"))

        # JSON Export
        box = layout.box()
        box.label(text="JSON Export", icon="FILE_TEXT")
        if not has_data:
            box.label(text="Zuerst OSM-Daten laden!", icon="ERROR")
        else:
            r = json_count(sc.get("_osm_roads",    "[]"))
            b = json_count(sc.get("_osm_buildings", "[]"))
            t = json_count(sc.get("_osm_trees",    "[]"))
            box.label(text=f"{r} Straßen · {b} Gebäude · {t} Bäume")
        row = box.row()
        row.enabled = has_data
        row.operator("osm.export_json", icon="FILE_TEXT", text="Als JSON speichern")

        layout.separator()

        # FBX Export
        box = layout.box()
        box.label(text="FBX → Unreal Engine 5", icon="EXPORT")
        box.prop(sc, "osm_export_path")
        box.operator("osm.export_fbx", icon="EXPORT", text="FBX exportieren")
        box.label(text="Buildings · Roads · Vegetation", icon="INFO")
