"""
OSM Daten laden und reichhaltig parsen.
Extrahiert: Gebäude (mit Höhe, Typ, Dachform), Straßen (mit Breite), Vegetation, Gewässer.
"""

import bpy, urllib.request, urllib.parse, json, math
from bpy.types import Operator

# ── Konstanten ────────────────────────────────────────────────────────────────

ROAD_WIDTHS = {
    "motorway": 14, "trunk": 12, "primary": 10, "secondary": 8,
    "tertiary": 6,  "residential": 5, "service": 3,
    "footway": 1.5, "cycleway": 1.5, "path": 1.2, "steps": 1.0,
}

BUILDING_TYPES = {
    "church":"church", "cathedral":"church", "chapel":"church",
    "industrial":"industrial", "warehouse":"industrial", "factory":"industrial",
    "garage":"garage", "garages":"garage",
    "house":"house", "detached":"house", "semidetached_house":"house",
    "apartments":"apartments", "residential":"apartments",
    "commercial":"commercial", "retail":"commercial", "shop":"commercial",
    "office":"office",
    "yes":"generic", "building":"generic",
}

ROOF_SHAPES = {"gabled","hipped","pyramidal","dome","onion","mansard","gambrel"}

# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def latlon_to_xy(lat, lon, olat, olon):
    R = 6_371_000
    x = R * math.radians(lon - olon) * math.cos(math.radians(olat))
    y = R * math.radians(lat - olat)
    return x, y

def build_query(lat, lon, radius):
    r = radius / 111_000
    bbox = f"{lat-r},{lon-r},{lat+r},{lon+r}"
    return f"""
[out:json][timeout:30];
(
  way["building"]({bbox});
  way["highway"]({bbox});
  way["natural"="tree_row"]({bbox});
  way["landuse"="forest"]({bbox});
  way["landuse"="meadow"]({bbox});
  way["natural"="water"]({bbox});
  node["natural"="tree"]({bbox});
);
(._;>;);
out body;
"""

def fetch(query):
    data = urllib.parse.urlencode({"data": query}).encode()
    req  = urllib.request.Request(
        "https://overpass-api.de/api/interpreter", data=data,
        headers={"User-Agent": "OSM-Blender-Addon/2.0", "Accept": "*/*"}
    )
    with urllib.request.urlopen(req, timeout=35) as r:
        return json.loads(r.read().decode())

def parse(osm, olat, olon):
    nodes = {}
    trees = []  # einzelne Baum-Nodes

    for el in osm["elements"]:
        if el["type"] == "node":
            x, y = latlon_to_xy(el["lat"], el["lon"], olat, olon)
            nodes[el["id"]] = (x, y)
            if el.get("tags", {}).get("natural") == "tree":
                trees.append({"x": x, "y": y})

    buildings, roads, vegetation, water = [], [], [], []

    for el in osm["elements"]:
        if el["type"] != "way":
            continue
        coords = [nodes[n] for n in el["nodes"] if n in nodes]
        if not coords:
            continue
        tags = el.get("tags", {})

        if "building" in tags:
            # Höhe ermitteln: direkt > levels*floor_h > default
            raw_h   = tags.get("height", "").replace("m","").strip()
            height  = float(raw_h) if raw_h else None
            levels  = None
            raw_lvl = tags.get("building:levels","").strip()
            if raw_lvl.isdigit():
                levels = int(raw_lvl)

            btype     = BUILDING_TYPES.get(tags.get("building","yes"), "generic")
            roof_raw  = tags.get("roof:shape","flat").lower()
            roof      = roof_raw if roof_raw in ROOF_SHAPES else "flat"
            roof_lvls = int(tags.get("roof:levels", 0) or 0)
            name      = tags.get("name","")

            buildings.append({
                "coords": coords, "height": height, "levels": levels,
                "type": btype, "roof": roof, "roof_levels": roof_lvls, "name": name,
            })

        elif "highway" in tags:
            hw    = tags.get("highway","residential")
            lanes = int(tags.get("lanes", 0) or 0)
            width = float(tags.get("width","0").replace("m","").strip() or 0)
            if width == 0:
                width = lanes * 3.5 if lanes else ROAD_WIDTHS.get(hw, 5.0)
            roads.append({"coords": coords, "highway": hw, "width": width,
                          "name": tags.get("name",""), "oneway": tags.get("oneway","no")})

        elif tags.get("natural") in ("tree_row",) or tags.get("landuse") in ("forest","meadow"):
            vegetation.append({"coords": coords, "type": tags.get("landuse", tags.get("natural",""))})

        elif tags.get("natural") == "water" or tags.get("waterway"):
            water.append({"coords": coords})

    return buildings, roads, vegetation, water, trees

# ── Operator ─────────────────────────────────────────────────────────────────

class OSM_OT_FetchData(Operator):
    bl_idname = "osm.fetch_data"
    bl_label  = "OSM Daten laden"
    bl_description = "Lädt Gebäude, Straßen, Vegetation und Gewässer von OpenStreetMap"

    def execute(self, context):
        sc = context.scene
        try:
            self.report({"INFO"}, "Verbinde mit Overpass API …")
            osm = fetch(build_query(sc.osm_lat, sc.osm_lon, sc.osm_radius))
            buildings, roads, veg, water, trees = parse(osm, sc.osm_lat, sc.osm_lon)

            sc["_osm_buildings"]  = json.dumps(buildings)
            sc["_osm_roads"]      = json.dumps(roads)
            sc["_osm_vegetation"] = json.dumps(veg)
            sc["_osm_water"]      = json.dumps(water)
            sc["_osm_trees"]      = json.dumps(trees)

            self.report({"INFO"},
                f"✓ {len(buildings)} Gebäude · {len(roads)} Straßen · "
                f"{len(veg)} Vegetation · {len(trees)} Bäume geladen")
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        return {"FINISHED"}
