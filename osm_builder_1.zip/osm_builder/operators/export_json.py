"""
Exportiert OSM-Straßen- und Gebäudedaten als strukturierte JSON-Datei.

Format:
{
  "meta": { lat, lon, radius, exported_at },
  "roads": [
    {
      "name": "...",
      "highway": "residential",
      "width_m": 5.0,
      "oneway": false,
      "points": [[x, y], [x, y], ...]   ← lokale Meter-Koordinaten
    }
  ],
  "buildings": [
    {
      "name": "...",
      "type": "house",
      "height_m": 9.0,
      "levels": 3,
      "roof": "flat",
      "footprint": [[x, y], ...]
    }
  ],
  "trees": [
    { "x": 12.3, "y": 45.6, "height_m": 6.0, "radius_m": 2.0 }
  ]
}
"""

import bpy
import json
import os
from datetime import datetime
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper


class OSM_OT_ExportJSON(Operator, ExportHelper):
    bl_idname  = "osm.export_json"
    bl_label   = "OSM Daten als JSON exportieren"
    bl_description = "Speichert alle geladenen OSM-Daten als JSON-Datei"

    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={"HIDDEN"})

    export_roads:     bpy.props.BoolProperty(name="Straßen",  default=True)
    export_buildings: bpy.props.BoolProperty(name="Gebäude",  default=True)
    export_trees:     bpy.props.BoolProperty(name="Bäume",    default=True)
    use_meters:       bpy.props.BoolProperty(name="Koordinaten in Metern (sonst cm)", default=True)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Was exportieren?", icon="EXPORT")
        layout.prop(self, "export_roads")
        layout.prop(self, "export_buildings")
        layout.prop(self, "export_trees")
        layout.separator()
        layout.prop(self, "use_meters")

    def execute(self, context):
        sc = context.scene

        # Prüfen ob Daten vorhanden
        if not sc.get("_osm_roads") and not sc.get("_osm_buildings"):
            self.report({"ERROR"}, "Keine OSM-Daten geladen! Zuerst 'OSM Daten laden' klicken.")
            return {"CANCELLED"}

        scale = 1.0 if self.use_meters else 100.0  # intern alles in Metern

        output = {
            "meta": {
                "latitude":    sc.osm_lat,
                "longitude":   sc.osm_lon,
                "radius_m":    sc.osm_radius,
                "exported_at": datetime.now().isoformat(timespec="seconds"),
                "coordinates": "local_meters" if self.use_meters else "local_cm",
                "origin":      "center of radius",
            }
        }

        # ── Straßen ───────────────────────────────────────────────────────────
        if self.export_roads and sc.get("_osm_roads"):
            raw_roads = json.loads(sc["_osm_roads"])
            roads_out = []
            for r in raw_roads:
                roads_out.append({
                    "name":     r.get("name", ""),
                    "highway":  r.get("highway", ""),
                    "width_m":  round(r.get("width", 5.0), 2),
                    "oneway":   r.get("oneway", False),
                    "lanes":    r.get("tags", {}).get("lanes", ""),
                    "points":   [[round(p[0]*scale, 3), round(p[1]*scale, 3)]
                                  for p in r["coords"]],
                })
            output["roads"] = roads_out
            output["meta"]["road_count"] = len(roads_out)

        # ── Gebäude ───────────────────────────────────────────────────────────
        if self.export_buildings and sc.get("_osm_buildings"):
            raw_buildings = json.loads(sc["_osm_buildings"])
            buildings_out = []
            for b in raw_buildings:
                height = b.get("height")
                levels = b.get("levels")
                if not height and levels:
                    height = levels * sc.osm_floor_height
                elif not height:
                    height = sc.osm_default_floors * sc.osm_floor_height

                buildings_out.append({
                    "name":       b.get("name", ""),
                    "type":       b.get("type", "generic"),
                    "height_m":   round(float(height) * scale, 2) if height else None,
                    "levels":     levels or sc.osm_default_floors,
                    "roof":       b.get("roof", "flat"),
                    "footprint":  [[round(p[0]*scale, 3), round(p[1]*scale, 3)]
                                    for p in b["coords"]],
                })
            output["buildings"] = buildings_out
            output["meta"]["building_count"] = len(buildings_out)

        # ── Bäume ─────────────────────────────────────────────────────────────
        if self.export_trees and sc.get("_osm_trees"):
            raw_trees = json.loads(sc["_osm_trees"])
            trees_out = []
            for t in raw_trees:
                trees_out.append({
                    "x":        round(t["x"] * scale, 3),
                    "y":        round(t["y"] * scale, 3),
                    "height_m": round(t.get("height", 6.0) * scale, 2),
                    "radius_m": round(t.get("radius", 2.0) * scale, 2),
                })
            output["trees"] = trees_out
            output["meta"]["tree_count"] = len(trees_out)

        # ── Speichern ─────────────────────────────────────────────────────────
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2, ensure_ascii=False)

            size_kb = os.path.getsize(self.filepath) / 1024
            self.report({"INFO"},
                f"✓ Exportiert nach: {self.filepath} ({size_kb:.1f} KB)")
        except Exception as e:
            self.report({"ERROR"}, f"Fehler beim Speichern: {e}")
            return {"CANCELLED"}

        return {"FINISHED"}
