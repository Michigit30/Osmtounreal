import bpy
from bpy.types import Operator

class OSM_OT_ClearScene(Operator):
    bl_idname = "osm.clear_scene"
    bl_label  = "Szene leeren"
    bl_description = "Löscht alle generierten OSM-Objekte und Collections"

    def execute(self, context):
        removed = 0
        for col_name in ("OSM_Buildings","OSM_Roads","OSM_Vegetation"):
            col = bpy.data.collections.get(col_name)
            if col:
                for obj in list(col.objects):
                    bpy.data.objects.remove(obj, do_unlink=True)
                bpy.data.collections.remove(col)
                removed += 1

        # Materialien aufräumen
        for mat in list(bpy.data.materials):
            if mat.name.startswith("OSM_"):
                bpy.data.materials.remove(mat)

        # Meshes aufräumen
        for me in list(bpy.data.meshes):
            if me.name.startswith("OSM_"):
                bpy.data.meshes.remove(me)

        self.report({"INFO"}, f"✓ Szene geleert ({removed} Collections entfernt)")
        return {"FINISHED"}
