"""
Gebäude-Generator v3 – kombiniert Umriss-Genauigkeit mit sauberer Mesh-Qualität.

Architektur:
  • Wände: echte Extrusion des OSM-Polygons → exakter Grundriss
  • Wand-Segmentierung: Flächen werden in Fenster/Tür/Wand-Segmente unterteilt
  • Materialien: pro Segment mit UV-Koordinaten für Textur-Tiling
  • Dach: flat (Attika), gabled (Giebel), hipped (Walm), pyramidal, shed
  • Custom-Mesh: entlang jeder Kante instanziert und skaliert (wie v1)
  • Alles in einem einzigen sauberen Mesh-Objekt pro Gebäude
"""

import bpy, bmesh, json, math, random
from mathutils import Vector
from bpy.types import Operator

# ── Gebäudetyp → Farben ───────────────────────────────────────────────────────

WALL_COLORS = {
    "church":     (0.86, 0.83, 0.78),
    "industrial": (0.52, 0.50, 0.46),
    "garage":     (0.58, 0.56, 0.53),
    "house":      (0.90, 0.80, 0.66),
    "apartments": (0.76, 0.72, 0.67),
    "commercial": (0.68, 0.74, 0.82),
    "office":     (0.62, 0.70, 0.84),
    "generic":    (0.82, 0.77, 0.68),
}
ROOF_COLORS = {
    "church":     (0.28, 0.26, 0.52),
    "industrial": (0.38, 0.36, 0.33),
    "house":      (0.60, 0.28, 0.14),
    "generic":    (0.52, 0.24, 0.14),
}
WINDOW_COLOR  = (0.45, 0.60, 0.75)
DOOR_COLOR    = (0.35, 0.22, 0.12)
SOCKEL_COLOR  = (0.60, 0.57, 0.52)

# ── Material-Cache ────────────────────────────────────────────────────────────

_mat_cache = {}

def get_mat(name, color, roughness=0.85, metallic=0.0):
    key = name
    if key in _mat_cache:
        return _mat_cache[key]
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = nt.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value  = roughness
        bsdf.inputs["Metallic"].default_value   = metallic
    _mat_cache[key] = mat
    return mat

# ── Geometrie-Helfer ──────────────────────────────────────────────────────────

def signed_area(coords):
    a = 0.0
    n = len(coords)
    for i in range(n):
        j = (i+1) % n
        a += coords[i][0] * coords[j][1]
        a -= coords[j][0] * coords[i][1]
    return a / 2.0

def ensure_ccw(coords):
    if signed_area(coords) < 0:
        return list(reversed(coords))
    return list(coords)

def polygon_centroid(coords):
    return (sum(c[0] for c in coords)/len(coords),
            sum(c[1] for c in coords)/len(coords))

def bounding_box(coords):
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    return min(xs), max(xs), min(ys), max(ys)

def edge_len(p1, p2):
    return math.sqrt((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2)

def edge_dir(p1, p2):
    l = edge_len(p1, p2)
    if l < 1e-6: return (1.0, 0.0)
    return ((p2[0]-p1[0])/l, (p2[1]-p1[1])/l)

# ── Wand-Mesh mit Segmentierung ───────────────────────────────────────────────

def add_wall_face(bm, p1, p2, z0, z1, uv_layer, u_start, u_end, mat_idx):
    """Fügt ein einzelnes Wand-Viereck hinzu mit UV-Koordinaten."""
    v0 = bm.verts.new(Vector((p1[0], p1[1], z0)))
    v1 = bm.verts.new(Vector((p2[0], p2[1], z0)))
    v2 = bm.verts.new(Vector((p2[0], p2[1], z1)))
    v3 = bm.verts.new(Vector((p1[0], p1[1], z1)))
    face = bm.faces.new([v0, v1, v2, v3])
    face.material_index = mat_idx
    # UV setzen
    h = z1 - z0
    loop_uvs = [(u_start, 0.0), (u_end, 0.0), (u_end, h), (u_start, h)]
    for loop, uv in zip(face.loops, loop_uvs):
        loop[uv_layer].uv = uv
    return face

def build_wall_segment(bm, p1, p2, floor_z, floor_h, seg_w, uv_layer,
                        floor_idx, is_ground, rng, mat_indices):
    """
    Unterteilt eine Kante in Segmente und weist Fenster/Tür/Wand zu.
    mat_indices: dict mit keys wall/window/door/sockel → material index
    """
    length  = edge_len(p1, p2)
    n_segs  = max(1, round(length / seg_w))
    actual  = length / n_segs

    dx = (p2[0]-p1[0]) / n_segs
    dy = (p2[1]-p1[1]) / n_segs

    # Sockel (nur EG, unteres Drittel)
    if is_ground:
        sockel_h = min(0.4, floor_h * 0.15)
        for i in range(n_segs):
            sp1 = (p1[0]+dx*i,     p1[1]+dy*i)
            sp2 = (p1[0]+dx*(i+1), p1[1]+dy*(i+1))
            u0, u1 = (i*actual), ((i+1)*actual)
            add_wall_face(bm, sp1, sp2, floor_z, floor_z+sockel_h, uv_layer,
                          u0, u1, mat_indices["sockel"])
        wall_z0 = floor_z + sockel_h
    else:
        wall_z0 = floor_z
        sockel_h = 0.0

    # Wandsegmente
    for i in range(n_segs):
        sp1 = (p1[0]+dx*i,     p1[1]+dy*i)
        sp2 = (p1[0]+dx*(i+1), p1[1]+dy*(i+1))
        u0, u1 = i*actual, (i+1)*actual

        # Tür: erstes Segment im EG
        if is_ground and i == 0:
            door_w = min(actual * 0.5, 1.2)
            door_h = floor_h * 0.75
            mid_x  = (sp1[0]+sp2[0])/2
            mid_y  = (sp1[1]+sp2[1])/2
            half   = actual/2
            dir_x, dir_y = edge_dir(sp1, sp2)
            dl1 = (mid_x - dir_x*door_w/2, mid_y - dir_y*door_w/2)
            dl2 = (mid_x + dir_x*door_w/2, mid_y + dir_y*door_w/2)
            # Wand links von Tür
            add_wall_face(bm, sp1, dl1, wall_z0, floor_z+floor_h, uv_layer,
                          u0, u0+half-door_w/2, mat_indices["wall"])
            # Tür
            add_wall_face(bm, dl1, dl2, wall_z0, wall_z0+door_h, uv_layer,
                          0, door_w, mat_indices["door"])
            # Wand über Tür
            add_wall_face(bm, dl1, dl2, wall_z0+door_h, floor_z+floor_h, uv_layer,
                          0, door_w, mat_indices["wall"])
            # Wand rechts von Tür
            add_wall_face(bm, dl2, sp2, wall_z0, floor_z+floor_h, uv_layer,
                          u0+half+door_w/2, u1, mat_indices["wall"])

        # Fenster: jedes 2. Segment ab OG oder jedes 3. im EG
        elif (not is_ground and i % 2 == 0) or (is_ground and i % 3 == 1):
            win_w  = actual * 0.45
            win_h  = floor_h * 0.45
            win_y0 = wall_z0 + floor_h * 0.30
            win_y1 = win_y0 + win_h
            mid_x  = (sp1[0]+sp2[0])/2
            mid_y  = (sp1[1]+sp2[1])/2
            dir_x, dir_y = edge_dir(sp1, sp2)
            wl1 = (mid_x - dir_x*win_w/2, mid_y - dir_y*win_w/2)
            wl2 = (mid_x + dir_x*win_w/2, mid_y + dir_y*win_w/2)
            # Wand unter Fenster
            add_wall_face(bm, sp1, sp2, wall_z0, win_y0, uv_layer, u0, u1, mat_indices["wall"])
            # Wand links
            add_wall_face(bm, sp1, wl1, win_y0, win_y1, uv_layer, u0, u0+(actual-win_w)/2, mat_indices["wall"])
            # Fenster
            add_wall_face(bm, wl1, wl2, win_y0, win_y1, uv_layer, 0, win_w, mat_indices["window"])
            # Wand rechts
            add_wall_face(bm, wl2, sp2, win_y0, win_y1, uv_layer, u1-(actual-win_w)/2, u1, mat_indices["wall"])
            # Wand über Fenster
            add_wall_face(bm, sp1, sp2, win_y1, floor_z+floor_h, uv_layer, u0, u1, mat_indices["wall"])

        else:
            # Normale Wand
            add_wall_face(bm, sp1, sp2, wall_z0, floor_z+floor_h, uv_layer,
                          u0, u1, mat_indices["wall"])

# ── Dach-Generatoren ──────────────────────────────────────────────────────────

def add_flat_roof(bm, coords, base_z, uv_layer, mat_idx):
    """Flachdach mit Attika."""
    thickness = 0.35
    overhang  = 0.15

    # Attika-Ring (außen)
    vb_out = [bm.verts.new(Vector((c[0], c[1], base_z)))             for c in coords]
    vt_out = [bm.verts.new(Vector((c[0], c[1], base_z+thickness)))  for c in coords]
    # Dachfläche (leicht eingerückt)
    inset = 0.3
    cx, cy = polygon_centroid(coords)
    inner  = []
    for c in coords:
        dx = c[0]-cx; dy = c[1]-cy
        l  = max(math.sqrt(dx*dx+dy*dy), 0.01)
        inner.append((c[0]-dx/l*inset, c[1]-dy/l*inset))
    vi_top = [bm.verts.new(Vector((c[0], c[1], base_z+thickness))) for c in inner]

    bm.verts.ensure_lookup_table()
    n = len(coords)
    for i in range(n):
        j = (i+1)%n
        # Attika-Außenseite
        f = bm.faces.new([vb_out[i], vb_out[j], vt_out[j], vt_out[i]])
        f.material_index = mat_idx
        # Attika-Oberseite
        f = bm.faces.new([vt_out[i], vt_out[j], vi_top[j], vi_top[i]])
        f.material_index = mat_idx
    # Dachfläche
    try:
        f = bm.faces.new(vi_top)
        f.material_index = mat_idx
    except:
        pass

def add_gabled_roof(bm, coords, base_z, uv_layer, mat_idx):
    """Giebeldach entlang der längsten Achse."""
    xmin, xmax, ymin, ymax = bounding_box(coords)
    cx, cy = polygon_centroid(coords)
    w = xmax-xmin; h = ymax-ymin
    roof_h = min(w,h) * 0.35

    base_verts = [bm.verts.new(Vector((c[0], c[1], base_z))) for c in coords]
    bm.verts.ensure_lookup_table()

    if w >= h:
        r1 = bm.verts.new(Vector((xmin + w*0.1, cy, base_z+roof_h)))
        r2 = bm.verts.new(Vector((xmax - w*0.1, cy, base_z+roof_h)))
    else:
        r1 = bm.verts.new(Vector((cx, ymin + h*0.1, base_z+roof_h)))
        r2 = bm.verts.new(Vector((cx, ymax - h*0.1, base_z+roof_h)))

    bm.verts.ensure_lookup_table()
    n = len(base_verts)

    # Versuche saubere Giebel-Faces basierend auf Seiten
    half = n // 2
    try:
        f = bm.faces.new([base_verts[i] for i in range(half+1)] + [r2, r1])
        f.material_index = mat_idx
        f = bm.faces.new([base_verts[i] for i in range(half, n)] + [base_verts[0], r1, r2])
        f.material_index = mat_idx
    except:
        # Fallback: Pyramide
        apex = bm.verts.new(Vector((cx, cy, base_z+roof_h)))
        bm.verts.ensure_lookup_table()
        for i in range(n):
            j = (i+1)%n
            try:
                f = bm.faces.new([base_verts[i], base_verts[j], apex])
                f.material_index = mat_idx
            except: pass

def add_pyramidal_roof(bm, coords, base_z, uv_layer, mat_idx):
    cx, cy = polygon_centroid(coords)
    xmin, xmax, ymin, ymax = bounding_box(coords)
    roof_h = min(xmax-xmin, ymax-ymin) * 0.4

    base_verts = [bm.verts.new(Vector((c[0], c[1], base_z))) for c in coords]
    apex       = bm.verts.new(Vector((cx, cy, base_z+roof_h)))
    bm.verts.ensure_lookup_table()
    n = len(base_verts)
    for i in range(n):
        j = (i+1)%n
        try:
            f = bm.faces.new([base_verts[i], base_verts[j], apex])
            f.material_index = mat_idx
        except: pass

# ── Haupt-Generator ───────────────────────────────────────────────────────────

def generate_building(coords, height, floors, btype, roof_shape, floor_h,
                       seg_w, rng, variation, custom_wall, collection):
    """
    Erzeugt ein vollständiges Gebäude-Mesh in einer Collection.
    Wenn custom_wall gesetzt: nutzt dieses Mesh entlang der Kanten.
    Sonst: vollständig prozedural.
    """
    coords = ensure_ccw(coords[:-1] if coords[0]==coords[-1] else coords)
    if len(coords) < 3:
        return

    # ── Custom-Mesh-Modus (wie v1) ────────────────────────────────────────────
    if custom_wall:
        roof_obj = None
        for floor in range(floors):
            fz = floor * floor_h
            n  = len(coords)
            for i in range(n):
                p1, p2 = coords[i], coords[(i+1)%n]
                length = edge_len(p1, p2)
                angle  = math.atan2(p2[1]-p1[1], p2[0]-p1[0])
                n_segs = max(1, round(length / seg_w))
                actual = length / n_segs
                sx     = actual / seg_w
                dx = (p2[0]-p1[0])/n_segs
                dy = (p2[1]-p1[1])/n_segs
                for j in range(n_segs):
                    cx2 = p1[0]+dx*(j+0.5)
                    cy2 = p1[1]+dy*(j+0.5)
                    var = 1.0 + rng.uniform(-variation/400, variation/400)
                    obj = custom_wall.copy()
                    obj.data = custom_wall.data
                    obj.location = Vector((cx2, cy2, fz))
                    obj.rotation_euler = (0, 0, angle)
                    obj.scale = Vector((actual/2*var, seg_w/2, floor_h/2))
                    collection.objects.link(obj)
        return

    # ── Prozeduraler Modus ────────────────────────────────────────────────────

    # Farben mit Variation
    var_amt = variation / 100.0
    wc = WALL_COLORS.get(btype, WALL_COLORS["generic"])
    rc = ROOF_COLORS.get(btype, ROOF_COLORS["generic"])
    wall_c = tuple(min(1,max(0, c+rng.uniform(-var_amt*0.25, var_amt*0.25))) for c in wc)
    roof_c = tuple(min(1,max(0, c+rng.uniform(-var_amt*0.15, var_amt*0.15))) for c in rc)

    # Materialien (alle im selben Mesh)
    wall_mat   = get_mat(f"OSM_Wall_{btype}_{int(wall_c[0]*100)}", wall_c, 0.88)
    window_mat = get_mat("OSM_Window", WINDOW_COLOR, 0.10, 0.05)
    door_mat   = get_mat("OSM_Door",   DOOR_COLOR,   0.75)
    sockel_mat = get_mat("OSM_Sockel", SOCKEL_COLOR, 0.92)
    roof_mat   = get_mat(f"OSM_Roof_{btype}", roof_c, 0.80)

    mat_indices = {"wall":0, "window":1, "door":2, "sockel":3}

    me = bpy.data.meshes.new("OSM_Building")
    me.materials.append(wall_mat)    # 0
    me.materials.append(window_mat)  # 1
    me.materials.append(door_mat)    # 2
    me.materials.append(sockel_mat)  # 3
    me.materials.append(roof_mat)    # 4

    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")

    # ── Wände stockwerksweise ─────────────────────────────────────────────────
    n = len(coords)
    for floor in range(floors):
        fz        = floor * floor_h
        is_ground = (floor == 0)
        for i in range(n):
            p1, p2 = coords[i], coords[(i+1)%n]
            build_wall_segment(bm, p1, p2, fz, floor_h, seg_w, uv,
                               floor, is_ground, rng, mat_indices)

    # ── Dach ──────────────────────────────────────────────────────────────────
    roof_z = floors * floor_h
    if   roof_shape == "gabled":    add_gabled_roof   (bm, coords, roof_z, uv, 4)
    elif roof_shape == "pyramidal": add_pyramidal_roof (bm, coords, roof_z, uv, 4)
    else:                           add_flat_roof      (bm, coords, roof_z, uv, 4)

    # ── Mesh finalisieren ─────────────────────────────────────────────────────
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(me)
    bm.free()
    me.update()

    obj = bpy.data.objects.new("OSM_Building", me)
    # Smooth shading
    for poly in obj.data.polygons:
        poly.use_smooth = False
    collection.objects.link(obj)
    return obj

# ── Operator ─────────────────────────────────────────────────────────────────

class OSM_OT_BuildBuildings(Operator):
    bl_idname = "osm.build_buildings"
    bl_label  = "Gebäude generieren"
    bl_description = "Generiert Gebäude mit exaktem OSM-Grundriss und sauberem Mesh"

    def execute(self, context):
        sc  = context.scene
        raw = sc.get("_osm_buildings")
        if not raw:
            self.report({"ERROR"}, "Zuerst OSM-Daten laden!")
            return {"CANCELLED"}

        buildings   = json.loads(raw)
        floor_h     = sc.osm_floor_height
        def_floors  = sc.osm_default_floors
        seg_w       = 4.0
        rng         = random.Random(sc.osm_random_seed)
        variation   = sc.osm_variation
        custom_wall = bpy.data.objects.get(sc.osm_wall_mesh) if sc.osm_wall_mesh else None

        col = bpy.data.collections.get("OSM_Buildings")
        if col:
            for o in list(col.objects): bpy.data.objects.remove(o, do_unlink=True)
        else:
            col = bpy.data.collections.new("OSM_Buildings")
        if "OSM_Buildings" not in [c.name for c in bpy.context.scene.collection.children]:
            bpy.context.scene.collection.children.link(col)

        _mat_cache.clear()
        count = 0
        skipped = 0

        wm = context.window_manager
        wm.progress_begin(0, len(buildings))

        for i, b in enumerate(buildings):
            wm.progress_update(i)
            coords = b["coords"]
            if len(coords) < 3:
                skipped += 1
                continue

            # Höhe & Stockwerke ermitteln
            if b["height"]:
                height = float(b["height"])
                floors = max(1, round(height / floor_h))
            elif b["levels"]:
                floors = int(b["levels"])
                height = floors * floor_h
            else:
                floors = def_floors
                height = floors * floor_h

            # Variation nur auf Stockwerke ohne explizite Daten
            if not b["height"] and not b["levels"]:
                var = 1.0 + rng.uniform(-variation/200, variation/200)
                height *= var
                floors = max(1, round(height / floor_h))

            try:
                generate_building(
                    coords, height, floors, b["type"], b["roof"],
                    floor_h, seg_w, rng, variation, custom_wall, col
                )
                count += 1
            except Exception as e:
                skipped += 1

        wm.progress_end()
        self.report({"INFO"}, f"✓ {count} Gebäude generiert, {skipped} übersprungen")
        return {"FINISHED"}
