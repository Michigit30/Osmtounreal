import bpy
from bpy.types import Operator

class OSM_OT_ExportFBX(Operator):
    bl_idname = "osm.export_fbx"
    bl_label  = "Nach UE5 exportieren (FBX)"
    bl_description = "Exportiert alle OSM-Collections als FBX für Unreal Engine 5"

    def execute(self, context):
        sc = context.scene
        export_path = bpy.path.abspath(sc.osm_export_path)
        if not export_path.endswith("/"):
            export_path += "/"

        collections = ["OSM_Buildings", "OSM_Roads", "OSM_Vegetation"]
        exported = 0

        for col_name in collections:
            col = bpy.data.collections.get(col_name)
            if not col or not col.objects:
                continue

            # Alle Objekte der Collection selektieren
            bpy.ops.object.select_all(action="DESELECT")
            for obj in col.objects:
                obj.select_set(True)

            filepath = export_path + col_name + ".fbx"
            bpy.ops.export_scene.fbx(
                filepath=filepath,
                use_selection=True,
                global_scale=1.0,
                apply_unit_scale=True,
                apply_scale_options="FBX_SCALE_NONE",
                axis_forward="-Z",
                axis_up="Y",
                mesh_smooth_type="FACE",
                use_mesh_modifiers=True,
            )
            exported += 1
            self.report({"INFO"}, f"Exportiert: {filepath}")

        if exported == 0:
            self.report({"WARNING"}, "Keine OSM-Collections gefunden. Erst generieren!")
            return {"CANCELLED"}

        self.report({"INFO"}, f"✓ {exported} FBX-Dateien exportiert nach {export_path}")
        return {"FINISHED"}
