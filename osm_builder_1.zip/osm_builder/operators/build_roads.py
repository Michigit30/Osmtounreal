"""
Straßen-Generator v3 – saubere Mesh-Qualität mit korrekten Breiten.

Features:
  • Breite automatisch aus lanes/width/highway-Typ
  • Separate Materialien pro Straßentyp
  • Fahrbahnmarkierungen (Mittellinie) als eigenes Face
  • Bordstein als schmale Kante
  • Gehwege neben Hauptstraßen
  • Kreuzungsplatten an Knotenpunkten
  • Optionales Custom-Mesh (wird gestretcht)
"""

import bpy, bmesh, json, math
from collections import defaultdict
from mathutils import Vector
from bpy.types import Operator

ROAD_WIDTHS = {
    "motorway":14,"trunk":12,"primary":10,"secondary":8,
    "tertiary":6,"unclassified":5,"residential":5,"living_street":4,
    "service":3,"footway":1.5,"cycleway":2.0,"path":1.2,"steps":1.0,
    "pedestrian":4,
}
ROAD_COLORS = {
    "motorway":   (0.13,0.13,0.13),
    "trunk":      (0.15,0.15,0.15),
    "primary":    (0.18,0.18,0.18),
    "secondary":  (0.20,0.20,0.20),
    "tertiary":   (0.22,0.22,0.22),
    "residential":(0.25,0.25,0.25),
    "living_street":(0.28,0.27,0.25),
    "service":    (0.27,0.27,0.27),
    "footway":    (0.62,0.57,0.48),
    "cycleway":   (0.28,0.45,0.28),
    "default":    (0.23,0.23,0.23),
}
SIDEWALK_COLOR  = (0.58, 0.54, 0.50)
BORDSTEIN_COLOR = (0.50, 0.48, 0.45)
LINE_COLOR      = (0.85, 0.82, 0.70)

SIDEWALK_TYPES  = {"primary","secondary","tertiary","residential","living_street"}
IGNORE_TYPES    = {"steps"}

_mat_cache = {}

def get_mat(name, color, roughness=0.95):
    if name in _mat_cache: return _mat_cache[name]
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value  = roughness
    _mat_cache[name] = mat
    return mat

def seg_len(p1,p2):
    return math.sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)

def seg_angle(p1,p2):
    return math.atan2(p2[1]-p1[1], p2[0]-p1[0])

def offset_point(p, angle, dist):
    perp = angle + math.pi/2
    return (p[0]+math.cos(perp)*dist, p[1]+math.sin(perp)*dist)

def make_quad(bm, p1l, p1r, p2l, p2r, z, mat_idx, uv_layer=None):
    """Erstellt ein Viereck aus 4 Punkten."""
    v0 = bm.verts.new(Vector((p1l[0], p1l[1], z)))
    v1 = bm.verts.new(Vector((p1r[0], p1r[1], z)))
    v2 = bm.verts.new(Vector((p2r[0], p2r[1], z)))
    v3 = bm.verts.new(Vector((p2l[0], p2l[1], z)))
    face = bm.faces.new([v0, v1, v2, v3])
    face.material_index = mat_idx
    if uv_layer:
        length = seg_len(p1l, p2l)
        width  = seg_len(p1l, p1r)
        uvs    = [(0,0),(width,0),(width,length),(0,length)]
        for loop, uv in zip(face.loops, uvs):
            loop[uv_layer].uv = uv
    return face

def build_road_mesh(p1, p2, width, hw, col):
    """Erstellt ein vollständiges Straßenquerschnitt-Mesh."""
    angle = seg_angle(p1, p2)
    hw2   = width / 2.0
    road_z      = 0.015
    bordstein_z = 0.020
    gehweg_z    = 0.010

    road_color = ROAD_COLORS.get(hw, ROAD_COLORS["default"])
    road_mat   = get_mat(f"OSM_Road_{hw}", road_color)
    bord_mat   = get_mat("OSM_Bordstein", BORDSTEIN_COLOR, 0.90)
    sw_mat     = get_mat("OSM_Sidewalk",  SIDEWALK_COLOR,  0.92)
    line_mat   = get_mat("OSM_RoadLine",  LINE_COLOR,      0.80)

    me = bpy.data.meshes.new("OSM_Road")
    me.materials.append(road_mat)   # 0
    me.materials.append(bord_mat)   # 1
    me.materials.append(sw_mat)     # 2
    me.materials.append(line_mat)   # 3

    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")

    # Fahrbahn
    p1l = offset_point(p1, angle, -hw2)
    p1r = offset_point(p1, angle,  hw2)
    p2l = offset_point(p2, angle, -hw2)
    p2r = offset_point(p2, angle,  hw2)
    make_quad(bm, p1l, p1r, p2l, p2r, road_z, 0, uv)

    # Mittellinie (nur bei breiten Straßen)
    if width >= 6.0:
        line_w = 0.15
        p1ll = offset_point(p1, angle, -line_w/2)
        p1lr = offset_point(p1, angle,  line_w/2)
        p2ll = offset_point(p2, angle, -line_w/2)
        p2lr = offset_point(p2, angle,  line_w/2)
        make_quad(bm, p1ll, p1lr, p2ll, p2lr, road_z+0.002, 3, uv)

    # Bordstein + Gehweg bei relevanten Straßentypen
    if hw in SIDEWALK_TYPES:
        bord_w = 0.12
        bord_h = 0.06
        sw_w   = 1.5

        for side in (-1, 1):
            # Bordstein
            b_inner = offset_point(p1, angle, side*hw2)
            b_outer = offset_point(p1, angle, side*(hw2+bord_w))
            b_inner2= offset_point(p2, angle, side*hw2)
            b_outer2= offset_point(p2, angle, side*(hw2+bord_w))
            if side == -1:
                make_quad(bm, b_outer, b_inner, b_outer2, b_inner2, bordstein_z, 1, uv)
            else:
                make_quad(bm, b_inner, b_outer, b_inner2, b_outer2, bordstein_z, 1, uv)

            # Gehweg
            sw_inner = offset_point(p1, angle, side*(hw2+bord_w))
            sw_outer = offset_point(p1, angle, side*(hw2+bord_w+sw_w))
            sw_inner2= offset_point(p2, angle, side*(hw2+bord_w))
            sw_outer2= offset_point(p2, angle, side*(hw2+bord_w+sw_w))
            if side == -1:
                make_quad(bm, sw_outer, sw_inner, sw_outer2, sw_inner2, gehweg_z, 2, uv)
            else:
                make_quad(bm, sw_inner, sw_outer, sw_inner2, sw_outer2, gehweg_z, 2, uv)

    bm.to_mesh(me)
    bm.free()
    me.update()

    obj = bpy.data.objects.new("OSM_Road", me)
    col.objects.link(obj)
    return obj

def build_crossing(point, width, col):
    """Kreuzungsplatte an einem Knotenpunkt."""
    x, y = point
    hw = width/2 + 1.8  # etwas größer als die Straße
    mat = get_mat("OSM_Crossing", (0.20,0.20,0.20))
    me  = bpy.data.meshes.new("OSM_Crossing")
    bm  = bmesh.new()
    v0 = bm.verts.new(Vector((x-hw, y-hw, 0.012)))
    v1 = bm.verts.new(Vector((x+hw, y-hw, 0.012)))
    v2 = bm.verts.new(Vector((x+hw, y+hw, 0.012)))
    v3 = bm.verts.new(Vector((x-hw, y+hw, 0.012)))
    f  = bm.faces.new([v0,v1,v2,v3])
    f.material_index = 0
    bm.to_mesh(me)
    bm.free()
    me.materials.append(mat)
    obj = bpy.data.objects.new("OSM_Crossing", me)
    col.objects.link(obj)

def instance_road_mesh(src, p1, p2, width, col):
    length = seg_len(p1,p2)
    angle  = seg_angle(p1,p2)
    mx = (p1[0]+p2[0])/2
    my = (p1[1]+p2[1])/2
    obj = src.copy()
    obj.data = src.data
    obj.location = Vector((mx, my, 0))
    obj.rotation_euler = (0, 0, angle)
    obj.scale = Vector((length/2, width/2, 1))
    col.objects.link(obj)

class OSM_OT_BuildRoads(Operator):
    bl_idname = "osm.build_roads"
    bl_label  = "Straßen generieren"
    bl_description = "Generiert Straßen mit Bordstein, Gehwegen und Markierungen"

    def execute(self, context):
        sc  = context.scene
        raw = sc.get("_osm_roads")
        if not raw:
            self.report({"ERROR"}, "Zuerst OSM-Daten laden!")
            return {"CANCELLED"}

        roads       = json.loads(raw)
        custom_road = bpy.data.objects.get(sc.osm_road_mesh) if sc.osm_road_mesh else None

        col = bpy.data.collections.get("OSM_Roads")
        if col:
            for o in list(col.objects): bpy.data.objects.remove(o, do_unlink=True)
        else:
            col = bpy.data.collections.new("OSM_Roads")
        if "OSM_Roads" not in [c.name for c in bpy.context.scene.collection.children]:
            bpy.context.scene.collection.children.link(col)

        _mat_cache.clear()

        # Kreuzungspunkte finden
        from collections import Counter
        all_pts = []
        for r in roads:
            all_pts.extend([tuple(c) for c in r["coords"]])
        crossings = {p for p,n in Counter(all_pts).items() if n >= 3}
        placed_cross = set()

        count = 0
        wm = context.window_manager
        wm.progress_begin(0, len(roads))

        for i, road in enumerate(roads):
            wm.progress_update(i)
            hw     = road["highway"]
            coords = road["coords"]
            width  = road["width"]

            if hw in IGNORE_TYPES: continue

            for j in range(len(coords)-1):
                p1, p2 = coords[j], coords[j+1]
                if seg_len(p1,p2) < 0.5: continue

                if custom_road:
                    instance_road_mesh(custom_road, p1, p2, width, col)
                else:
                    build_road_mesh(p1, p2, width, hw, col)

                # Kreuzungsplatten
                key = tuple(p1)
                if key in crossings and key not in placed_cross:
                    placed_cross.add(key)
                    build_crossing(p1, width, col)

                count += 1

        wm.progress_end()
        self.report({"INFO"}, f"✓ {count} Straßensegmente generiert")
        return {"FINISHED"}
