"""
Vegetation-Generator.
- Einzelne Bäume aus OSM-Nodes
- Baumreihen entlang Wegen
- Wälder als Flächen mit zufällig platzierten Bäumen
- Optionales Baum-Mesh, sonst prozeduraler Kegelbaum
"""

import bpy, bmesh, json, math, random
from mathutils import Vector
from bpy.types import Operator

def get_mat(name, color):
    mat = bpy.data.materials.get(name)
    if mat: return mat
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Roughness"].default_value = 0.9
    return mat

def make_procedural_tree(height=5.0, radius=2.0):
    """Erstellt einen einfachen Kegelbaum (Stamm + Krone)."""
    me = bpy.data.meshes.new("OSM_Tree")
    bm = bmesh.new()

    # Stamm
    trunk_h = height * 0.35
    trunk_r = radius * 0.12
    segs = 6
    bot = [bm.verts.new(Vector((math.cos(i*2*math.pi/segs)*trunk_r,
                                 math.sin(i*2*math.pi/segs)*trunk_r, 0))) for i in range(segs)]
    top = [bm.verts.new(Vector((math.cos(i*2*math.pi/segs)*trunk_r,
                                 math.sin(i*2*math.pi/segs)*trunk_r, trunk_h))) for i in range(segs)]
    bm.verts.ensure_lookup_table()
    for i in range(segs):
        bm.faces.new([bot[i], bot[(i+1)%segs], top[(i+1)%segs], top[i]])

    # Krone (Kegel)
    crown_segs = 8
    crown_base = [bm.verts.new(Vector((math.cos(i*2*math.pi/crown_segs)*radius,
                                        math.sin(i*2*math.pi/crown_segs)*radius, trunk_h))) for i in range(crown_segs)]
    apex = bm.verts.new(Vector((0, 0, height)))
    bm.verts.ensure_lookup_table()
    for i in range(crown_segs):
        bm.faces.new([crown_base[i], crown_base[(i+1)%crown_segs], apex])
    bm.faces.new(crown_base)

    bm.to_mesh(me)
    bm.free()
    return me

def place_tree(x, y, height, radius, custom_obj, col, trunk_mat, crown_mat):
    if custom_obj:
        obj = custom_obj.copy()
        obj.data = custom_obj.data
        obj.location = Vector((x, y, 0))
        obj.scale = Vector((radius/2, radius/2, height/5))
        col.objects.link(obj)
    else:
        me = make_procedural_tree(height, radius)
        # Materialien zuweisen
        me.materials.append(trunk_mat)
        me.materials.append(crown_mat)
        obj = bpy.data.objects.new("OSM_Tree", me)
        obj.location = Vector((x, y, 0))
        col.objects.link(obj)

def point_in_polygon(px, py, coords):
    inside = False
    n = len(coords)
    j = n-1
    for i in range(n):
        xi, yi = coords[i]
        xj, yj = coords[j]
        if ((yi > py) != (yj > py)) and (px < (xj-xi)*(py-yi)/(yj-yi)+xi):
            inside = not inside
        j = i
    return inside

class OSM_OT_BuildVegetation(Operator):
    bl_idname = "osm.build_vegetation"
    bl_label  = "Vegetation generieren"
    bl_description = "Platziert Bäume aus OSM-Daten"

    def execute(self, context):
        sc         = context.scene
        raw_trees  = sc.get("_osm_trees")
        raw_veg    = sc.get("_osm_vegetation")
        if not raw_trees and not raw_veg:
            self.report({"ERROR"}, "Zuerst OSM-Daten laden!")
            return {"CANCELLED"}

        rng        = random.Random(sc.osm_random_seed + 1)
        custom_obj = bpy.data.objects.get(sc.osm_tree_mesh) if sc.osm_tree_mesh else None

        trunk_mat = get_mat("OSM_Trunk", (0.35, 0.22, 0.10))
        crown_mat = get_mat("OSM_Crown", tuple(sc.osm_vegetation_color))

        col = bpy.data.collections.get("OSM_Vegetation") or bpy.data.collections.new("OSM_Vegetation")
        if "OSM_Vegetation" not in bpy.context.scene.collection.children:
            bpy.context.scene.collection.children.link(col)

        count = 0

        # Einzelne Bäume
        if raw_trees:
            for t in json.loads(raw_trees):
                h = rng.uniform(4.0, 8.0)
                r = rng.uniform(1.5, 3.0)
                place_tree(t["x"], t["y"], h, r, custom_obj, col, trunk_mat, crown_mat)
                count += 1

        # Waldflächen / Baumreihen
        if raw_veg:
            for veg in json.loads(raw_veg):
                coords = veg["coords"]
                vtype  = veg["type"]

                if vtype == "tree_row":
                    # Bäume entlang der Linie
                    for i in range(len(coords)-1):
                        p1, p2 = coords[i], coords[i+1]
                        length = math.sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)
                        n_trees = max(1, int(length / 8))
                        for k in range(n_trees):
                            t = (k+0.5)/n_trees
                            x = p1[0] + (p2[0]-p1[0])*t + rng.uniform(-0.5,0.5)
                            y = p1[1] + (p2[1]-p1[1])*t + rng.uniform(-0.5,0.5)
                            h = rng.uniform(5.0, 9.0)
                            r = rng.uniform(1.8, 3.2)
                            place_tree(x, y, h, r, custom_obj, col, trunk_mat, crown_mat)
                            count += 1

                elif vtype in ("forest",):
                    # Zufällige Bäume innerhalb der Fläche
                    if len(coords) < 3: continue
                    from .build_buildings import bounding_box
                    xmin, xmax, ymin, ymax = bounding_box(coords)
                    area = (xmax-xmin) * (ymax-ymin)
                    density = 1.0 / 40.0  # 1 Baum pro 40m²
                    n_trees = int(area * density)
                    placed = 0
                    attempts = 0
                    while placed < n_trees and attempts < n_trees*5:
                        attempts += 1
                        x = rng.uniform(xmin, xmax)
                        y = rng.uniform(ymin, ymax)
                        if point_in_polygon(x, y, coords):
                            h = rng.uniform(6.0, 12.0)
                            r = rng.uniform(2.0, 4.0)
                            place_tree(x, y, h, r, custom_obj, col, trunk_mat, crown_mat)
                            placed += 1
                            count += 1

        self.report({"INFO"}, f"✓ {count} Bäume platziert")
        return {"FINISHED"}
